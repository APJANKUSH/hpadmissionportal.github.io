-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 22, 2014 at 07:07 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `admission_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_us`
--

CREATE TABLE `about_us` (
  `About_us_id` int(20) NOT NULL auto_increment,
  `Description` varchar(3000) NOT NULL,
  PRIMARY KEY  (`About_us_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `about_us`
--

INSERT INTO `about_us` (`About_us_id`, `Description`) VALUES
(1, 'adstg\r\n123444'),
(2, 'safrrt'),
(3, 'adss\r\n\r\n'),
(4, 'icecream\r\n\r\n\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `admission_procedure`
--

CREATE TABLE `admission_procedure` (
  `Admission_procedure_id` int(20) NOT NULL auto_increment,
  `Course_id` int(20) NOT NULL,
  `Description` varchar(3000) NOT NULL,
  PRIMARY KEY  (`Admission_procedure_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `admission_procedure`
--

INSERT INTO `admission_procedure` (`Admission_procedure_id`, `Course_id`, `Description`) VALUES
(1, 23, 'asgr gnj,'),
(2, 233, 'assfsg'),
(3, 654, 'vaqrs'),
(4, 344, 'asdfg'),
(5, 2, 'des'),
(6, 12, 'addmin'),
(7, 22, 'ash'),
(9, 11, 'as'),
(10, 9, 'desc'),
(11, 6, 'good'),
(12, 9, 'hg'),
(13, 7, 'asd'),
(14, 7, 'asd'),
(15, 6, 'asg'),
(16, 6, 'asg'),
(17, 6, 'ash'),
(18, 6, 'ash');

-- --------------------------------------------------------

--
-- Table structure for table `advertisement`
--

CREATE TABLE `advertisement` (
  `Advertisement_id` int(30) NOT NULL auto_increment,
  `Name` varchar(20) NOT NULL,
  `Description` varchar(4000) NOT NULL,
  `Image` varchar(500) NOT NULL,
  PRIMARY KEY  (`Advertisement_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `advertisement`
--

INSERT INTO `advertisement` (`Advertisement_id`, `Name`, `Description`, `Image`) VALUES
(1, 'null', 'null', 'null'),
(2, 'null', 'null', 'null'),
(3, 'null', 'null', 'null'),
(4, 'null', 'null', 'null'),
(5, 'null', 'null', 'null'),
(6, 'null', 'null', 'null'),
(7, 'ashu', 'hi', 'null'),
(8, 'Ashwini', 'helo', 'null'),
(9, 'vs', 'hgfhsj', 'null');

-- --------------------------------------------------------

--
-- Table structure for table `college_course`
--

CREATE TABLE `college_course` (
  `College_course_id` int(20) NOT NULL auto_increment,
  `College_id` int(20) NOT NULL,
  `Course_id` int(20) NOT NULL,
  `Course_fees` varchar(50000) NOT NULL,
  `Seat_available` varchar(3000) NOT NULL,
  PRIMARY KEY  (`College_course_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=90 ;

--
-- Dumping data for table `college_course`
--

INSERT INTO `college_course` (`College_course_id`, `College_id`, `Course_id`, `Course_fees`, `Seat_available`) VALUES
(1, 776, 64, '664', '7'),
(12, 23, 34, '2345', '2234'),
(34, 23, 34, '3000', '2234'),
(39, 12, 2, '200', '400'),
(67, 45, 65, '400', '800'),
(68, 23, 3, '1234', '233'),
(69, 23, 3, '1234', '233'),
(72, 33, 9, '3000', '300'),
(73, 33, 10, '2000', '200'),
(74, 33, 11, '2000', '50'),
(75, 33, 12, '21000', '100'),
(79, 32, 6, '20000', '100'),
(80, 32, 7, '21000', '200'),
(81, 30, 6, '21000', '99'),
(82, 30, 7, '20000', '50'),
(83, 30, 9, '3000', '200'),
(84, 30, 10, '2000', '200'),
(85, 30, 11, '4000', '100'),
(86, 30, 12, '23000', '200'),
(88, 31, 9, '3000', '100'),
(89, 31, 10, '2000', '100');

-- --------------------------------------------------------

--
-- Table structure for table `college_master`
--

CREATE TABLE `college_master` (
  `College_id` int(20) NOT NULL auto_increment,
  `College_code` varchar(20) NOT NULL,
  `College_name` varchar(30) NOT NULL,
  `College_Description` varchar(5000) NOT NULL,
  `Address` varchar(500) NOT NULL,
  `Contact_person` varchar(20) NOT NULL,
  `Contact_number` varchar(20) NOT NULL,
  `Prospectors` varchar(500) NOT NULL,
  `Image` varchar(600) NOT NULL,
  PRIMARY KEY  (`College_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `college_master`
--

INSERT INTO `college_master` (`College_id`, `College_code`, `College_name`, `College_Description`, `Address`, `Contact_person`, `Contact_number`, `Prospectors`, `Image`) VALUES
(30, '555', 'bk', 'desc', 'add', 'ash', '9919919911', 'asdf', 'DSC01846.JPG'),
(31, '333', 'ssr', 'best', 'mudalgi', 'vij', '8889922331', 'as2', 'DSC01856.JPG'),
(32, '444', 'TRL', 'good', 'nagar', 'sachi', '953858688', 'abc', 'IMG0212A.jpg'),
(33, '222', 'vsm', 'better', 'nipani', 'chetan', '7722445566', 'chet', 'DSC01558.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `course_master`
--

CREATE TABLE `course_master` (
  `Course_id` int(20) NOT NULL auto_increment,
  `Course_name` varchar(30) NOT NULL,
  `Course_description` varchar(3000) NOT NULL,
  `Duration` varchar(400) NOT NULL,
  PRIMARY KEY  (`Course_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `course_master`
--

INSERT INTO `course_master` (`Course_id`, `Course_name`, `Course_description`, `Duration`) VALUES
(6, 'BCA', 'best', '3Years'),
(7, 'BBA', 'best', '3Years'),
(9, 'B com', 'good', '3Years'),
(10, 'BA', 'good', '3Years'),
(11, 'BSW', 'good', '3Years'),
(12, 'B sc', 'good', '3Years');

-- --------------------------------------------------------

--
-- Table structure for table `facilities`
--

CREATE TABLE `facilities` (
  `Facility_id` int(30) NOT NULL auto_increment,
  `College_id` int(30) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Description` varchar(6000) NOT NULL,
  PRIMARY KEY  (`Facility_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=221 ;

--
-- Dumping data for table `facilities`
--

INSERT INTO `facilities` (`Facility_id`, `College_id`, `Name`, `Description`) VALUES
(2, 354, 'fdh', 'dey'),
(3, 123, 'ashu', 'ashu'),
(4, 345, 'sfg', 'ghjkkdfdgdg'),
(12, 22, 'adsfgbd', 'dsv'),
(212, 122, 'adf', 'fsef'),
(213, 12, 'vwg', 'desc'),
(214, 12, 'adsd', 'asd1234'),
(215, 12, 'adsd', 'asd1'),
(216, 12, 'ashu', 'asdd121'),
(217, 12, 'cdcdc', 'dsf33'),
(218, 12, 'asdd', 'asddf'),
(219, 12, 'var', 'f'),
(220, 30, 'COMPUTER LAB', 'coputers');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `From` varchar(200) NOT NULL,
  `Subject` varchar(300) NOT NULL,
  `Feedback` varchar(800) NOT NULL,
  `Date1` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`From`, `Subject`, `Feedback`, `Date1`) VALUES
('student', 'addmision', 'best', '2014-10-10'),
('ash', 'add', 'good', '2014-11-11'),
('san', 'hii', 'hello', 'Sun Dec 21 13:19:09 ');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `User_name` varchar(40) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Type` varchar(40) NOT NULL,
  `Hint_question` varchar(3000) NOT NULL,
  `Hint_answer` varchar(3000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`User_name`, `Password`, `Type`, `Hint_question`, `Hint_answer`) VALUES
('admin', '123123', 'admin', 'b', 'c'),
('student', '123123', 'student', 'j', 'h'),
('college', '123123', 'college', 's', 'f'),
('555', '555', 'college', 'Contacat No', '9919919911'),
('333', '333', 'college', 'Contacat No', '8889922331'),
('444', '444', 'college', 'Contacat No', '953858688'),
('222', '222', 'college', 'Contacat No', '7722445566'),
('san', '123123', 'student', 'My Registered Email Id', 'san@gmail.com'),
('777', '777', 'college', 'Contacat No', '8889922332'),
('ashi', 'ashi', 'student', 'My Registered Email Id', 'ashu@gmail.com'),
('varsha', 'varsha', 'student', 'My Registered Email Id', 'varsha@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `News_id` int(20) NOT NULL auto_increment,
  `Title` varchar(50) NOT NULL,
  `Description` varchar(4000) NOT NULL,
  `News_Date` varchar(30) NOT NULL,
  PRIMARY KEY  (`News_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`News_id`, `Title`, `Description`, `News_Date`) VALUES
(1, 'dfs', 'asdf', '35566'),
(2, 'asp', 'sda', '2013-4-30');

-- --------------------------------------------------------

--
-- Table structure for table `qualification`
--

CREATE TABLE `qualification` (
  `Qualification_id` int(20) NOT NULL auto_increment,
  `Student_id` int(30) NOT NULL,
  `Qualification_Name` varchar(40) NOT NULL,
  `Univercity_Name` varchar(40) NOT NULL,
  `Year_Of_Passing` varchar(20) NOT NULL,
  `Marks` varchar(100) NOT NULL,
  `Total_Marks` varchar(400) NOT NULL,
  `Persentage` varchar(80) NOT NULL,
  PRIMARY KEY  (`Qualification_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `qualification`
--

INSERT INTO `qualification` (`Qualification_id`, `Student_id`, `Qualification_Name`, `Univercity_Name`, `Year_Of_Passing`, `Marks`, `Total_Marks`, `Persentage`) VALUES
(5, 20, 'Science', 'k', '2000', 'null', '100', '10'),
(6, 22, 'Commerce', 'PUC', '2013', 'null', '490', '74'),
(7, 23, 'Commerce', 'RCU', '2013', 'null', '470', '74');

-- --------------------------------------------------------

--
-- Table structure for table `student_application`
--

CREATE TABLE `student_application` (
  `Application_id` int(20) NOT NULL auto_increment,
  `Student_id` int(30) NOT NULL,
  `Course_id` int(30) NOT NULL,
  `College_id` int(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `Application_date` varchar(400) NOT NULL,
  PRIMARY KEY  (`Application_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `student_application`
--

INSERT INTO `student_application` (`Application_id`, `Student_id`, `Course_id`, `College_id`, `status`, `Application_date`) VALUES
(1, 20, 6, 30, 'Selected', '20-12-2014'),
(2, 22, 7, 30, 'Rejected', '21-12-2014');

-- --------------------------------------------------------

--
-- Table structure for table `student_master`
--

CREATE TABLE `student_master` (
  `Student_id` int(20) NOT NULL auto_increment,
  `First_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `date_of_birth` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `cast` varchar(20) NOT NULL,
  `categories` varchar(10) NOT NULL,
  `email_id` varchar(40) NOT NULL,
  `photo` varchar(600) NOT NULL,
  `User_name` varchar(20) NOT NULL,
  PRIMARY KEY  (`Student_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `student_master`
--

INSERT INTO `student_master` (`Student_id`, `First_name`, `last_name`, `address`, `date_of_birth`, `age`, `gender`, `cast`, `categories`, `email_id`, `photo`, `User_name`) VALUES
(12, 'as', 'fg', 'vgfb', '2014-2-2', '2', '', 'sd', 'bg', 'ashu', '', 'va'),
(13, 'erfg', 'sdfg', 'adrry', '29/10/94', '21', 'null', 'xcvb', 'nbv', 'ashu', 'null', 'uj'),
(14, 'ash', 'As', 'DSs', '2014-9-9', '22', 'null', 'lingayat', '2b', 'null', 'null', 'AS'),
(16, 'fff', 'null', 'null', '2014-9-9', '24', 'null', 'null', 'null', 'null', 'null', 'null'),
(20, 'san', 'k', 'dwd', '08-04-1984', '30', 'male', 'h', '2A', 'san@gmail.com', 'photo', 'san'),
(21, 'ash', 'alatagi', 'mudalgi', '1994-10-29', '21', 'Female', 'hindu lingayat', 'null', 'ashu@gmail.com', 'null', 'ashu'),
(22, 'Ashwini', 'Alatagi', 'Mudalgi', '1994-10-29', '20', 'female', 'hindu lingayat', '3B', 'ashu@gmail.com', 'photo', 'ashi'),
(23, 'Varshadevi', 'Salalli', 'Raibag', '1994-4-17', '20', 'female', 'hindu lingayat', '3A', 'varsha@gmail.com', 'IMG_20140612_134423-1.jpg', 'varsha');
